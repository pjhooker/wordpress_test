<?php

add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );
function theme_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style', get_stylesheet_uri(), array( 'parent-style' ) );
}



function articoli_con_performance($IDSITE){

// The Query to show a specific Custom Field
$the_query = new WP_Query( array( 'posts_per_page' => -1, 'status' => 'publish', 'post_type' => 'performance' ) );

// The Loop
while ( $the_query->have_posts() ) : $the_query->the_post();

        $plink_obj=get_permalink();
        $post_object = get_field('link_website');

        //print_r($post_object);
        $id_obj=get_id_postobject($post_object);
        if ($IDSITE==$id_obj){
          echo "<a href='$plink_obj' class='wc-shortcodes-button wc-shortcodes-button-primary wc-shortcodes-button-position-float'>PERFORMANCE</a>";
        }


endwhile;
// Reset Post Data
wp_reset_postdata();

}

function get_id_postobject($post_object){
  if( $post_object ):

    // override $post
    $post = $post_object;
    setup_postdata( $post );

    return $post_object->ID;

    wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly

  endif;
}
