<?php
/**
 * The template part for displaying single posts
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>

<?php
	$post_object = get_field('link_website');

	if( $post_object ):

		// override $post
		$post = $post_object;
		setup_postdata( $post );

		$title_website=get_the_title();
		$plink_website=get_permalink();

		?>
		<script>console.log('<?php echo $title_website; ?>')</script>
		<?php

		wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly

	endif;

 $A = get_field('webmastertool');
 $B = get_field('analytics');
 $C = get_field('data_rilevamento');
 $D = get_field('periodo_di_riferimento');
 $E = get_field('visualizzazioni');
 $F = get_field('connessioni');
 $G = get_field('numero_post');

 $dates = explode(",", $C);
 //echo $dates[0]; // piece1
 //echo $dates[1]; // piece2

 $visualizzazioni = explode(",", $E);
 $connessioni = explode(",", $F);
 $contenuti = explode(",", $G);

 ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
	</header><!-- .entry-header -->

	<?php twentysixteen_excerpt(); ?>

	<?php twentysixteen_post_thumbnail(); ?>

	<div class="entry-content">

	<div>
		<h3>Descrizione sito: <a href="<?php echo $plink_website; ?>"><?php echo $title_website; ?></a></h3>
	</div>

		<?php

			the_content();


			echo "<ul>";

				if ($A==0){$icon="<i class='fa fa-square-o'></i>";}
				else if ($A==1){$icon="<i class='fa fa-check-square'></i>";}
				echo "<li>Connessione a strumenti per monitorare gli errori $icon</li>";

				if ($B==0){$icon="<i class='fa fa-square-o'></i>";}
				else if ($B==1){$icon="<i class='fa fa-check-square'></i>";}
				echo "<li>Strumenti di analytics o insight $icon</li>";

			echo "</ul>";

			echo "<h3>Periodo riferimento dati: $D</h3>";

?>

			<div style="background-color:white;padding:5px;margin-top:25px;">
				<table cellpadding="0" cellspacing="0" border="0" class="display" id="example" class="pretty"></table>
			</div>

<?php


			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentysixteen' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );

			if ( '' !== get_the_author_meta( 'description' ) ) {
				get_template_part( 'template-parts/biography' );
			}
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php twentysixteen_entry_meta(); ?>
		<?php
			edit_post_link(
				sprintf(
					/* translators: %s: Name of current post */
					__( 'Edit<span class="screen-reader-text"> "%s"</span>', 'twentysixteen' ),
					get_the_title()
				),
				'<span class="edit-link">',
				'</span>'
			);
		?>
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->



<script>

	var arrE = new Array();
	var arrF = new Array();
	var arrG = new Array();

	<?php
	foreach ($visualizzazioni as &$value) {
	?>
		arrE.push(<?php echo $value;?>);
	<?php
	}

	foreach ($connessioni as &$value) {
	?>
		arrF.push(<?php echo $value;?>);
	<?php
	}

	foreach ($contenuti as &$value) {
	?>
		arrG.push(<?php echo $value;?>);
	<?php
	}
	?>
	//console.log(arrE);

</script>


<script>

$( document ).ready(function() {

	$( "#example" ).addClass( "pretty" );
	//console.log( "ready!" );

	var dataSet = new Array();
	var arr = new Array();

	var thisCOUNT = 0;

	console.log(<?php echo $C;?>);

	$.each([<?php echo $C;?>], function (key, val) {

		arr=[];

		arr.push(val); //data_rilevamento
		arr.push(arrE[thisCOUNT]);
		arr.push(arrF[thisCOUNT]);
		arr.push(arrG[thisCOUNT]);

		dataSet.push(arr);

		thisCOUNT++;
	}); // EACH -end

	var table = $('#example').DataTable( {
		searching:  false,
		paging:  true,
		"ordering": false,
		"data": dataSet,
		"columns": [
			{ "title": "Data" },
			{ "title": "Visualizz." },
			{ "title": "Conness." },
			{ "title": "Contenuti" }
		]/*,
		"createdRow": function ( row, data, index ) {
			//if ( data[2].replace(/[\$,]/g, '') * 1 > 150000 ) {
					$('td', row).addClass('highlight');
			//}
		}*/
	});
});
</script>
